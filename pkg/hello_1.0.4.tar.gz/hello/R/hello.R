#' Hello
#' @export
hello <- function() {
  print("Hello, world!")
}
